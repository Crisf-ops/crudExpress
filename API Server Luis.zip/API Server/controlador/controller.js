const express = require('express');
const router = express.Router();
const data = require('../modelo/data')
const dataUser = require('../modelo/dataUser')


router.get('/', function(req, res){
    res.status(200).json(data);
})

router.get('/:id', function(req,res){
    let found = data.find(function(item){
        return item.id === parseInt(req.params.id)
    });
    if(found){
        res.status(200).json(found);
    } else {
        res.sendStatus(404)
    }

});

router.post('/', function(req,res){
    let  itemIds= data.map (item => item.id);

    let newId = itemIds.length > 0 ? Math.max.apply(Math, itemIds) +1 : 1;

// let newItem = {
//     id: newId,
//     nombre: req.body.nombre,
//     pais: req.body.pais,
//     Telefono: req.body.Telefono,
//     active: req.body.active,
//     createdOn: new Date()
//     }   
let newUser = new dataUser(newId,req.body.nombre,req.body.pais,req.body.telefono,req.body.active,new Date())

    data.push(newUser);
    res.status(201).json(newUser);

});

router.put('/:id', function (req, res) {
    let found = data.find(function (item) {
        return item.id === parseInt(req.params.id);
    });

    if (found) {
        // let updated = {
        //     id: found.id, 
        //     nombre: typeof(req.body.nombre) != "undefined" ? req.body.nombre: found.nombre,
        //     pais: typeof(req.body.pais) != "undefined" ? req.body.pais: found.pais,
        //     Telefono: typeof(req.body.Telefono) != "undefined" ? req.body.Telefono: found.Telefono,
        //     active: typeof(req.body.active) != "undefined" ? req.body.active: found.active,
        //     createdOn: found.createdOn
        // };
let newUser = new dataUser();
newUser.id = found.id;
newUser.nombre = typeof(req.body.nombre) != "undefined" ? req.body.nombre: found.nombre;
newUser.pais = typeof(req.body.pais) != "undefined" ? req.body.pais: found.pais;
newUser.telefono = typeof(req.body.Telefono) != "undefined" ? req.body.Telefono: found.Telefono;
newUser.active = typeof(req.body.active) != "undefined" ? req.body.active: found.active;
newUser.createdON = found.createdOn;

        let targetIndex = data.indexOf(found);

        data.splice(targetIndex, 1, newUser);

        res.sendStatus(200);
    } else {
        res.sendStatus(404);
    }
});


router.delete('/:id', function(req,res){
    let found = data.find(function(item){
        return item.id === parseInt (req.params.id)
    })
    if(found){
        let targetIndex = data.indexOf(found)
        data.splice(targetIndex, 1);
        res.sendStatus(200);
    } else{
        res.sendStatus(404);
    }
})

module.exports = router;