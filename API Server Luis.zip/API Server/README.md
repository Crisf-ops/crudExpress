# Laboratorio API automation

Este servidor fue creado para ayudar a entender como podemos realizar API testing

## instalar dependencias
npm install
## Para corre el servidor
* 'npm start'
