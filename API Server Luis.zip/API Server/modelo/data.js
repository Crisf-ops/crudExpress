const data = [
    {id: 1, nombre: 'Luis Leguizamon', Pais: 'Colombia', Telefono: 3103213000, active: true, createdOn: new Date()},
    {id: 2, nombre: 'Cristian Arredondo', Pais: 'Colombia', Telefono: 3103213001, active: false, createdOn: new Date()},
    {id: 3, nombre: 'Audy Chavarria', Pais: 'Colombia', Telefono: 3103213003, active: true, createdOn: new Date()}
]
module.exports = data;