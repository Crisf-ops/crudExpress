class dataUser {
    constructor(id,nombre,pais,telefono,active,createdON){
    this.id = id,
    this.nombre = nombre,
    this.pais = pais,
    this.telefono = telefono,
    this.active = active,
    this.createdON = createdON
    }
}

module.exports = dataUser;